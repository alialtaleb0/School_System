<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Certificate extends Model
{
    protected $fillable = [
        'student_id',
        'enrollment_id',
        'academic_year',
        'level',
        'section',
        'final_grade',
        'status',
        'token',
        'qr_code_path',
    ];

    // ─── العلاقات ───────────────────────────────────────────

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function enrollment()
    {
        return $this->belongsTo(StudentEnrollment::class);
    }

    // ─── Accessor: رابط صورة QR كامل ────────────────────────

    public function getQrCodeUrlAttribute(): ?string
    {
        return $this->qr_code_path
            ? asset('storage/' . $this->qr_code_path)
            : null;
    }
}
