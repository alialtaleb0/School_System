<?php

namespace App\Http\Controllers;

use App\Models\Schedule;
use App\Models\Section;
use App\Models\Timetable;
use Illuminate\Http\Request;

class TimetableController extends Controller
{
    /**
     * عرض جميع الجداول الزمنية
     */
    public function index()
    {
        if (auth()->user()->role !== 'admin') {
            return response()->json(['error' => 'Only admins can view timetables'], 403);
        }

        $timetables = Timetable::with([
            'section.level',
            'section.program',
            'schedules.subject',
            'schedules.teacher.user',
        ])->get();

        return response()->json([
            'message' => 'Timetables retrieved successfully',
            'data'    => $timetables,
        ]);
    }

    /**
     * إنشاء جدول زمني لشعبة معيّنة
     */
    public function store(Request $request)
    {
        if (auth()->user()->role !== 'admin') {
            return response()->json(['error' => 'Only admins can create timetables'], 403);
        }

        $data = $request->validate([
            'section_id' => 'required|exists:sections,id',
            'name'       => 'required|string|max:255',
            'start_date' => 'nullable|date',
            'end_date'   => 'nullable|date|after_or_equal:start_date',
        ]);

        $section = Section::with(['level', 'program'])->findOrFail($data['section_id']);

        // التحقق: الشعبة يجب أن تكون مرتبطة بمرحلة دراسية
        if (!$section->level) {
            return response()->json([
                'error' => 'The selected section has no associated level (grade).',
            ], 422);
        }

        $timetable = Timetable::create([
            'section_id' => $section->id,
            'name'       => $data['name'],
            'start_date' => $data['start_date'] ?? null,
            'end_date'   => $data['end_date'] ?? null,
        ]);

        return response()->json([
            'message' => 'Timetable created successfully',
            'data'    => $timetable->load([
                'section.level',
                'section.program',
            ]),
        ], 201);
    }

    /**
     * عرض جدول زمني محدد
     */
    public function show(Timetable $timetable)
    {
        if (auth()->user()->role !== 'admin') {
            return response()->json(['error' => 'Only admins can view timetables'], 403);
        }

        return response()->json([
            'message' => 'Timetable retrieved successfully',
            'data'    => $timetable->load([
                'section.level',
                'section.program',
                'schedules.subject',
                'schedules.teacher.user',
            ]),
        ]);
    }

    /**
     * تعديل جدول زمني
     */
    public function update(Request $request, Timetable $timetable)
    {
        if (auth()->user()->role !== 'admin') {
            return response()->json(['error' => 'Only admins can update timetables'], 403);
        }

        $data = $request->validate([
            'name'       => 'nullable|string|max:255',
            'start_date' => 'nullable|date',
            'end_date'   => 'nullable|date|after_or_equal:start_date',
        ]);

        $timetable->update(array_filter($data, fn($v) => !is_null($v)));

        return response()->json([
            'message' => 'Timetable updated successfully',
            'data'    => $timetable->load([
                'section.level',
                'section.program',
                'schedules.subject',
                'schedules.teacher.user',
            ]),
        ]);
    }

    /**
     * حذف جدول زمني
     */
    public function destroy(Timetable $timetable)
    {
        if (auth()->user()->role !== 'admin') {
            return response()->json(['error' => 'Only admins can delete timetables'], 403);
        }

        $timetable->delete();

        return response()->json([
            'message' => 'Timetable deleted successfully',
        ]);
    }

    /**
     * عرض الحصص الخاصة بجدول زمني معيّن
     */
    public function schedules($id)
    {
        if (auth()->user()->role !== 'admin') {
            return response()->json(['error' => 'Only admins can view timetable schedules'], 403);
        }

        $timetable = Timetable::with(['section.level', 'section.program'])->findOrFail($id);

        return response()->json([
            'message' => 'Timetable schedules retrieved successfully',
            'data'    => [
                'timetable' => $timetable,
                'schedules' => $timetable->schedules()->with(['subject', 'teacher.user'])->get(),
            ],
        ]);
    }

    /**
     * إضافة حصة لجدول زمني
     */
    public function addSchedule(Request $request, $id)
    {
        if (auth()->user()->role !== 'admin') {
            return response()->json(['error' => 'Only admins can add schedule entries'], 403);
        }

        $timetable = Timetable::findOrFail($id);

        $data = $request->validate([
            'subject_id' => 'required|exists:subjects,id',
            'teacher_id' => 'required|exists:teachers,id',
            'day'        => 'required|string|in:sunday,monday,tuesday,wednesday,thursday',
            'period'     => 'required|integer|min:1|max:7',
        ]);

        // التحقق من أن المعلم يدرّس هذه المادة
        $teacher = \App\Models\Teacher::findOrFail($data['teacher_id']);
        $doesTeachSubject = $teacher->subjects()->where('subject_id', $data['subject_id'])->exists();

        if (!$doesTeachSubject) {
            return response()->json([
                'error' => 'This teacher is not assigned to teach this subject.',
            ], 422);
        }

        // التحقق من عدم تكرار الحصة في نفس اليوم والفترة
        $existing = Schedule::where('timetable_id', $timetable->id)
            ->where('day', $data['day'])
            ->where('period', $data['period'])
            ->first();

        if ($existing) {
            return response()->json([
                'error' => 'This period already has a scheduled subject on that day.',
            ], 422);
        }

        $schedule = $timetable->schedules()->create($data);

        return response()->json([
            'message' => 'Schedule entry added successfully',
            'data'    => $schedule->load(['subject', 'teacher.user']),
        ], 201);
    }
}
