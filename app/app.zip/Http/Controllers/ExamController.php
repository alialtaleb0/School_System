<?php

namespace App\Http\Controllers;

use App\Models\Exam;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ExamController extends Controller
{
    /**
     * 1️⃣ عرض قائمة بجميع الامتحانات
     */
    public function index()
    {
        $exams = Exam::with(['subject', 'teacher.user'])->latest()->get();

        return response()->json([
            'message' => 'Exams retrieved successfully',
            'data' => $exams
        ]);
    }

    /**
     * 2️⃣ إنشاء امتحان جديد (معدلة للتحقق من مادة الأستاذ)
     * POST /api/exams
     */
    public function store(Request $request)
    {
        // 1. التحقق من صلاحية الأستاذ
        if (auth()->user()->role !== 'teacher') {
            return response()->json(['error' => 'Only teachers can create exams.'], 403);
        }

        $teacher = auth()->user()->teacher;

        // 2. التحقق من البيانات مع شرط أن تكون المادة تابعة للأستاذ الحالي
        $data = $request->validate([
            'subject_id' => [
                'required',
                'exists:subjects,id',
                // التحقق من وجود المادة داخل جدول الوسيط subject_teacher للأستاذ الحالي
                Rule::exists('subject_teacher', 'subject_id')->where(function ($query) use ($teacher) {
                    $query->where('teacher_id', $teacher->id);
                }),
            ],
            'name'       => 'required|string|max:255',
            'start_time' => 'required|date|after:now',
            'end_time'   => 'nullable|date|after:start_time',
        ], [
            // رسالة خطأ مخصصة باللغة العربية
            'subject_id.exists' => 'المادة المحددة غير موجودة أو غير مسندة إليك لتدريسها.',
        ]);

        // 3. إنشاء الامتحان
        $exam = Exam::create([
            'subject_id' => $data['subject_id'],
            'teacher_id' => $teacher->id,
            'name'       => $data['name'],
            'start_time' => $data['start_time'],
            'end_time'   => $data['end_time'],
        ]);

        return response()->json([
            'message' => 'Exam created successfully',
            'data' => $exam
        ], 201);
    }

    /**
     * 3️⃣ عرض امتحان معين بالتفصيل
     */
    public function show(Exam $exam)
    {
        $exam->load(['subject', 'teacher.user', 'grades.student.user']);

        return response()->json([
            'message' => 'Exam details retrieved successfully',
            'data' => $exam
        ]);
    }

    /**
     * 4️⃣ تعديل بيانات امتحان معين (معدلة للتحقق من المادة أيضاً)
     * PUT/PATCH /api/exams/{id}
     */
    public function update(Request $request, Exam $exam)
    {
        // التحقق من أن الأستاذ الحالي هو من أنشأ هذا الامتحان أصلاً
        if (auth()->user()->role !== 'teacher' || auth()->user()->teacher->id !== $exam->teacher_id) {
            return response()->json(['error' => 'Unauthorized. Only the exam creator can update it.'], 403);
        }

        $teacher = auth()->user()->teacher;

        $data = $request->validate([
            'subject_id' => [
                'sometimes',
                'required',
                'exists:subjects,id',
                // التأكد أن المادة الجديدة (في حال تعديلها) تابعة أيضاً للأستاذ
                Rule::exists('subject_teacher', 'subject_id')->where(function ($query) use ($teacher) {
                    $query->where('teacher_id', $teacher->id);
                }),
            ],
            'name'       => 'sometimes|required|string|max:255',
            'start_time' => 'sometimes|required|date',
            'end_time'   => 'nullable|date|after:start_time',
        ], [
            'subject_id.exists' => 'المادة المحددة غير مسندة إليك، لا يمكنك تحويل الامتحان إليها.',
        ]);

        $exam->update($data);

        return response()->json([
            'message' => 'Exam updated successfully',
            'data' => $exam
        ]);
    }

    /**
     * 5️⃣ حذف امتحان
     */
    public function destroy(Exam $exam)
    {
        if (auth()->user()->role !== 'teacher' || auth()->user()->teacher->id !== $exam->teacher_id) {
            return response()->json(['error' => 'Unauthorized. Only the exam creator can delete it.'], 403);
        }

        $exam->delete();

        return response()->json([
            'message' => 'Exam deleted successfully'
        ]);
    }

    /**
     * عرض الامتحانات القادمة
     */
    public function upcomingExams()
    {
        $upcoming = Exam::with(['subject', 'teacher.user'])
            ->where('start_time', '>', now())
            ->orderBy('start_time', 'asc')
            ->get();

        return response()->json([
            'message' => 'Upcoming exams retrieved successfully',
            'data' => $upcoming
        ]);
    }
}
