<?php

namespace App\Http\Controllers;

use App\Models\Grade;
use App\Models\Exam;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class GradeController extends Controller
{
    /**
     * عرض قائمة بالدرجات
     */
    public function index()
    {
        $grades = Grade::with(['student.user', 'exam.subject', 'teacher.user'])->latest()->get();
        return response()->json(['data' => $grades]);
    }

    /**
     * 1️⃣ إضافة درجة جديدة لطالب (معدلة للتحقق من مادة الأستاذ)
     * POST /api/grades
     */
    public function store(Request $request)
    {
        // 1. التأكد من أن المستخدم الحالي هو أستاذ
        if (auth()->user()->role !== 'teacher') {
            return response()->json(['error' => 'Only teachers can add grades.'], 403);
        }

        $teacher = auth()->user()->teacher;

        // 2. التحقق من البيانات المرسلة
        $data = $request->validate([
            'student_id' => 'required|exists:students,id',
            'exam_id' => [
                'required',
                'exists:exams,id',
                // شرط متقدم: التأكد من أن الامتحان ينتمي لمادة يدرّسها هذا الأستاذ
                function ($attribute, $value, $fail) use ($teacher) {
                    $exam = Exam::find($value);
                    if ($exam) {
                        // التحقق من وجود المادة الخاصة بالامتحان داخل جدول subject_teacher للأستاذ الحالي
                        $ownsSubject = \DB::table('subject_teacher')
                            ->where('teacher_id', $teacher->id)
                            ->where('subject_id', $exam->subject_id)
                            ->exists();

                        if (!$ownsSubject) {
                            $fail('لا يمكنك إضافة درجة لهذا الامتحان لأن مادته غير مسندة إليك.');
                        }
                    }
                },
            ],
            'mark' => 'required|numeric|min:0',
        ]);

        // 3. إنشاء سجل الدرجة (مع تخزين معرف الأستاذ الذي قام بالتصحيح/الإدخال)
        $grade = Grade::create([
            'student_id' => $data['student_id'],
            'exam_id'    => $data['exam_id'],
            'teacher_id' => $teacher->id, // الأستاذ الحالي هو المصحح
            'mark'       => $data['mark'],
        ]);

        return response()->json([
            'message' => 'Grade added successfully',
            'data' => $grade
        ], 201);
    }

    /**
     * عرض تفاصيل درجة معينة
     */
    public function show(Grade $grade)
    {
        $grade->load(['student.user', 'exam.subject', 'teacher.user']);
        return response()->json(['data' => $grade]);
    }

    /**
     * 2️⃣ تعديل درجة طالب (معدلة للتحقق من الصلاحية والمادة)
     * PUT/PATCH /api/grades/{id}
     */
    public function update(Request $request, Grade $grade)
    {
        if (auth()->user()->role !== 'teacher') {
            return response()->json(['error' => 'Unauthorized.'], 403);
        }

        $teacher = auth()->user()->teacher;

        // التأكد من أن الأستاذ الذي يحاول التعديل يدرّس مادة هذا الامتحان
        $exam = $grade->exam;
        $ownsSubject = \DB::table('subject_teacher')
            ->where('teacher_id', $teacher->id)
            ->where('subject_id', $exam->subject_id)
            ->exists();

        if (!$ownsSubject) {
            return response()->json(['error' => 'لا يمكنك تعديل هذه الدرجة لأن مادة الامتحان غير مسندة إليك.'], 403);
        }

        // التحقق من البيانات الجديدة في حال تم تعديل الامتحان أو العلامة
        $data = $request->validate([
            'exam_id' => [
                'sometimes',
                'required',
                'exists:exams,id',
                function ($attribute, $value, $fail) use ($teacher) {
                    $newExam = Exam::find($value);
                    if ($newExam) {
                        $ownsNewSubject = \DB::table('subject_teacher')
                            ->where('teacher_id', $teacher->id)
                            ->where('subject_id', $newExam->subject_id)
                            ->exists();

                        if (!$ownsNewSubject) {
                            $fail('الامتحان الجديد المختار ينتمي لمادة لا تدرّسها.');
                        }
                    }
                },
            ],
            'mark' => 'sometimes|required|numeric|min:0',
        ]);

        $grade->update($data);

        return response()->json([
            'message' => 'Grade updated successfully',
            'data' => $grade
        ]);
    }

    /**
     * حذف درجة
     */
    public function destroy(Grade $grade)
    {
        if (auth()->user()->role !== 'teacher') {
            return response()->json(['error' => 'Unauthorized.'], 403);
        }

        $teacher = auth()->user()->teacher;
        $exam = $grade->exam;

        // التحقق من أن مادة الامتحان تابعة للأستاذ قبل الحذف
        $ownsSubject = \DB::table('subject_teacher')
            ->where('teacher_id', $teacher->id)
            ->where('subject_id', $exam->subject_id)
            ->exists();

        if (!$ownsSubject) {
            return response()->json(['error' => 'لا تملك الصلاحية لحذف هذه الدرجة.'], 403);
        }

        $grade->delete();

        return response()->json(['message' => 'Grade deleted successfully']);
    }
}
